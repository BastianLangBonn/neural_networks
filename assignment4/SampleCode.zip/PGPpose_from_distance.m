function Rresu = PGPpose_from_distance(Pxinit,PP1,PP2,PP3,Pr,Piterlimit)
%function Rresu=pose_from_distance(Pxinit,PP1,PP2,PP3,Pr,Piterlimit)
%
%this function solves a set of 3 nonlinear equations 
%iteratively using Gauss-Newton algorithm
%the equations are the euclidian distances to 3 known light houses (given
%on the map), Pr contains these measured distances.
%
%Its main aim is to practize the interplay between symbolic
%MATLAB and numeric part.
%Details of the implemented algorithm may be found in:
%Numerische Mathematik, R Schwarz,N K�ckler, Vieweg/Teubner, 8.te Aufl. 
%Chapter 6.4.1. Gauss-Newton Methode
%
%NB: all vectors *MUST* be column vectors!
%(in) Pxinit : start value for iteration
%(in) PPi    : position of beacon i (as known from map)
%(in) Pr     : a vector of 3 distances as measured
%(in) Piterlimit: maximal number of iterations
%(out)Rresu  : [x;y] vector of estimated pose
%example usage :
% PGPpose_from_distance([10;10],[0;1],[-1;0],[0;-1],[1;1;1], 10)
% ans =
%    1.0e-16 *
%     0.2595
%    -0.3011

if (size(Pxinit,1) < size(Pxinit,2) |...
    size(PP1,1) < size(PP1,2) |...
    size(PP2,1) < size(PP2,2) |...
    size(PP3,1) < size(PP3,2) |...
    size(Pr,1) < size(Pr,2) )
    error('all input vectors must be column vectors..'),
    return
end
syms x y;%the unknowns in eq1..3
eq1   = sqrt( (PP1(1)-x)^2 + (PP1(2)-y)^2 );%circle arround beacon 1
eq2   = sqrt( (PP2(1)-x)^2 + (PP2(2)-y)^2 );
eq3   = sqrt( (PP3(1)-x)^2 + (PP3(2)-y)^2 );
myjac = jacobian([eq1;eq2;eq3],[x y]);
%
xcurr    = Pxinit;%current approximation, init val: usually choosen as Center of Gravity of PP1,PP3,PP3
chi_curr = ones(size(PP1));%correction step, is added to x_curr to find NEW current approximation
d        = zeros(size(Pr));%residual between current approx. and measurment
n        = 0;%current loop count, is limited by iterlimit
while ( norm(chi_curr) > 100000*eps & n < Piterlimit)%second stop criterion: numerical precision
    myjaceval = double(subs(myjac,{x,y},{xcurr(1),xcurr(2)}));%evaluate JACOBIAN at current spot
%
    d(1) = Pr(1) - double(subs(eq1,{x,y},{xcurr(1),xcurr(2)}));%residuals: measured - current approx.
    d(2) = Pr(2) - double(subs(eq2,{x,y},{xcurr(1),xcurr(2)}));
    d(3) = Pr(3) - double(subs(eq3,{x,y},{xcurr(1),xcurr(2)}));
%
    chi_curr = myjaceval\d;%LMS solve matrix myjacevel for difference (use left-divide "\")
    xcurr    = xcurr + chi_curr;%add solution, get new best approximation
    n=n+1; 
end
Rresu=xcurr;
