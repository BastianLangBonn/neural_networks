function test_pose_from_distance2()
%test case for the pose_from_distance fct
clear;
testname  = 'pose_from_distance';
testnumber = 1;
%setup test 1
fprintf('Start:<%s> No.<%d> ',testname,testnumber)
PP = [ 0 0; 4 0; 2 4];
PP1=PP(1,:);
PP1=PP1';
PP2=PP(2,:);
PP2=PP2';
PP3=PP(3,:);
PP3=PP3';
%
Pxinit = mean(PP);
Pxinit = Pxinit';
Pr     = [2*sqrt(2);2*sqrt(2);2];
distort= [0.1;0.1;-0.05];
Pr     = Pr+distort;
expected = [2;2.0957];
iterlimit = 10;
%do test
resu     = PGPpose_from_distance(Pxinit,PP1,PP2,PP3,Pr,iterlimit);
if ( abs(max(resu-expected))> 10000*eps )
   fprintf('%s: Test No. %d failed\n',testname,testnumber)
   error('Test ERROR exit')
else
  fprintf(' OK\n')
  testnumber = testnumber +1;
end
%tear down
clear PP1 PP2 PP3 PP Pxinit Pr distort expected iterlimit;
%test end
%%
%setup test 2
fprintf('Start:<%s> No.<%d> ',testname,testnumber)
PP = [ 0 0; 4 0; 2 4];
PP1=PP(1,:);
PP1=PP1';
PP2=PP(2,:);
PP2=PP2';
PP3=PP(3,:);
PP3=PP3';
%
Pxinit = mean(PP);
Pxinit = Pxinit';
Pr     = [2*sqrt(2);2*sqrt(2);2];
distort= [-0.1;-0.1;-0.1];
Pr     = Pr+distort;
expected = [2;2];
iterlimit = 10;
%do test
resu     = PGPpose_from_distance(Pxinit,PP1,PP2,PP3,Pr,iterlimit);
if ( abs(max(resu-expected))> 10000*eps )
   fprintf(' failed\n',testname,testnumber)
   error('Test ERROR => exit')
else
  fprintf(' OK\n')
  testnumber = testnumber +1;
end
%tear down
clear PP1 PP2 PP3 PP Pxinit Pr distort expected iterlimit;
%test end
%%
%setup test 3
fprintf('Start:<%s> No.<%d> ',testname,testnumber)
PP = [ 0 0; 4 0; 6 0];
PP1=PP(1,:);
PP1=PP1';
PP2=PP(2,:);
PP2=PP2';
PP3=PP(3,:);
PP3=PP3';
%
Pxinit = mean(PP);
Pxinit = Pxinit';
Pr     = [2;2;4];
distort= [-eps;-eps;eps];
Pr     = Pr+distort;
expected = [2;0];
iterlimit = 10;
%do test
resu     = PGPpose_from_distance(Pxinit,PP1,PP2,PP3,Pr,iterlimit);
if ( abs(max(resu-expected))> 10000*eps )
   fprintf(' failed\n',testname,testnumber)
   error('Test ERROR => exit')
else
  fprintf(' OK\n')
  testnumber = testnumber +1;
end
%tear down
clear PP1 PP2 PP3 PP Pxinit Pr distort expected iterlimit;
%test end
%%
%setup test 4
fprintf('Start:<%s> No.<%d> ',testname,testnumber)
PP = [ 0 eps; 4 -eps; 6 -eps];
PP1=PP(1,:);
PP1=PP1';
PP2=PP(2,:);
PP2=PP2';
PP3=PP(3,:);
PP3=PP3';
%
Pxinit = mean(PP);
Pxinit = Pxinit';
Pr     = [2;2;4];
distort= [-eps;-eps;eps];
Pr     = Pr+distort;
expected = [2;0];
iterlimit = 10;
%do test
resu     = PGPpose_from_distance(Pxinit,PP1,PP2,PP3,Pr,iterlimit);
if ( abs(max(resu-expected))> 10000*eps )
   fprintf(' failed\n',testname,testnumber)
   error('Test ERROR => exit')
else
  fprintf(' OK\n')
  testnumber = testnumber +1;
end
%tear down
clear PP1 PP2 PP3 PP Pxinit Pr distort expected iterlimit;
%test end
%%
%setup test 5
fprintf('Start:<%s> No.<%d> ',testname,testnumber)
PP = [ 0 0; 4 0; 2 4];
PP1=PP(1,:);
PP1=PP1';
PP2=PP(2,:);
PP2=PP2';
PP3=PP(3,:);
PP3=PP3';
%
Pxinit = [-100;-100];
Pr     = [2*sqrt(2);2*sqrt(2);2];
distort= [0;0;0];
Pr     = Pr+distort;
expected = [2;2];
iterlimit = 10;
%do test
resu     = PGPpose_from_distance(Pxinit,PP1,PP2,PP3,Pr,iterlimit);
if ( abs(max(resu-expected))> 10000*eps )
   fprintf(' failed\n',testname,testnumber)
   error('Test ERROR => exit')
else
  fprintf(' OK\n')
  testnumber = testnumber +1;
end
%tear down
clear PP1 PP2 PP3 PP Pxinit Pr distort expected iterlimit;
%test end%%
%%
%setup test 6
fprintf('Start:<%s> No.<%d> ',testname,testnumber)
PP = [ 0 0; 4 0; 2 4];
PP1=PP(1,:);
PP1=PP1';
PP2=PP(2,:);
PP2=PP2';
PP3=PP(3,:);
PP3=PP3';
%
Pxinit = [100000;100000];
Pr     = [2*sqrt(2);2*sqrt(2);2];
distort= [0;0;0];
Pr     = Pr+distort;
expected = [2;2];
iterlimit = 10;
%do test
resu     = PGPpose_from_distance(Pxinit,PP1,PP2,PP3,Pr,iterlimit);
if ( abs(max(resu-expected))> 10000*eps )
   fprintf(' failed\n',testname,testnumber)
   error('Test ERROR => exit')
else
  fprintf(' OK\n')
  testnumber = testnumber +1;
end
%tear down
clear PP1 PP2 PP3 PP Pxinit Pr distort expected iterlimit;
%test end%%
fprintf('End  :<%s>\n',testname)
%%
clear
end

